const money = (value) => new Intl.NumberFormat("es-HN", {
  style: "currency", currency: "HNL", maximumFractionDigits: 2
}).format(value);

const chartInstances = {};

function createChart(id, config) {
  if (chartInstances[id]) chartInstances[id].destroy();
  const canvas = document.getElementById(id);
  chartInstances[id] = new Chart(canvas, config);
}

async function getJson(endpoint) {
  const response = await fetch(endpoint);
  if (!response.ok) throw new Error(`Error al consultar ${endpoint}: ${response.status}`);
  return response.json();
}

async function loadDashboard() {
  const error = document.getElementById("errorMessage");
  error.textContent = "";

  try {
    const [count, sum, avg, maxMin, categories, months, sellers, sales] = await Promise.all([
      getJson("/api/estadisticas/count"),
      getJson("/api/estadisticas/sum"),
      getJson("/api/estadisticas/avg"),
      getJson("/api/estadisticas/max-min"),
      getJson("/api/estadisticas/categorias"),
      getJson("/api/estadisticas/meses"),
      getJson("/api/estadisticas/vendedores"),
      getJson("/api/ventas")
    ]);

    document.getElementById("totalVentas").textContent = count.totalVentas;
    document.getElementById("ingresosTotales").textContent = money(sum.ingresosTotales);
    document.getElementById("promedioVenta").textContent = money(avg.promedioVenta);

    createChart("categoriasChart", {
      type: "doughnut",
      data: {
        labels: categories.map(item => item.categoria),
        datasets: [{ data: categories.map(item => item.ingresos), backgroundColor: ["#3767e8", "#38bda4", "#f5ad52"], borderWidth: 0 }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: "bottom" }, tooltip: { callbacks: { label: context => `${context.label}: ${money(context.raw)}` } } } }
    });

    createChart("mesesChart", {
      type: "bar",
      data: {
        labels: months.map(item => item.mes),
        datasets: [{ label: "Cantidad de ventas", data: months.map(item => item.cantidad), backgroundColor: "#3767e8", borderRadius: 7, maxBarThickness: 42 }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } }
    });

    createChart("vendedoresChart", {
      type: "bar",
      data: {
        labels: sellers.map(item => item.vendedor),
        datasets: [{ label: "Ingresos", data: sellers.map(item => item.ingresos), backgroundColor: ["#38bda4", "#3767e8", "#f5ad52"], borderRadius: 7 }]
      },
      options: { indexAxis: "y", responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: context => money(context.raw) } } }, scales: { x: { beginAtZero: true, ticks: { callback: value => money(value) } } } }
    });

    createChart("maxMinChart", {
      type: "bar",
      data: {
        labels: ["Venta mínima", "Venta máxima"],
        datasets: [{ label: "Valor de la venta", data: [maxMin.ventaMinima.total, maxMin.ventaMaxima.total], backgroundColor: ["#f5ad52", "#3767e8"], borderRadius: 8, maxBarThickness: 85 }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: context => money(context.raw) } } }, scales: { y: { beginAtZero: true, ticks: { callback: value => money(value) } } } }
    });

    document.getElementById("maxMinDetalle").textContent =
      `Mayor: ${maxMin.ventaMaxima.producto} (${money(maxMin.ventaMaxima.total)}). Menor: ${maxMin.ventaMinima.producto} (${money(maxMin.ventaMinima.total)}).`;

    document.getElementById("ventasBody").innerHTML = sales.map(item => `
      <tr>
        <td>${item.producto}</td><td>${item.categoria}</td><td>${item.vendedor}</td>
        <td>${item.mes}</td><td>${item.cantidad}</td><td>${money(item.cantidad * item.precio)}</td>
      </tr>`).join("");
  } catch (err) {
    error.textContent = "No se pudieron cargar los datos. Verifica que el servidor esté iniciado. " + err.message;
    document.getElementById("ventasBody").innerHTML = '<tr><td colspan="6">No hay datos disponibles.</td></tr>';
  }
}

document.getElementById("refreshBtn").addEventListener("click", loadDashboard);
loadDashboard();