const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Datos de ejemplo para demostrar las funciones de agregacion.
// Pueden sustituirse por los datos reales de la clase o de una base de datos.
const ventas = [
  { id: 1, producto: "Laptop", categoria: "Tecnologia", vendedor: "Ana", cantidad: 2, precio: 18500, mes: "Enero" },
  { id: 2, producto: "Mouse", categoria: "Accesorios", vendedor: "Luis", cantidad: 8, precio: 350, mes: "Enero" },
  { id: 3, producto: "Teclado", categoria: "Accesorios", vendedor: "Ana", cantidad: 5, precio: 850, mes: "Febrero" },
  { id: 4, producto: "Monitor", categoria: "Tecnologia", vendedor: "Carlos", cantidad: 3, precio: 6200, mes: "Febrero" },
  { id: 5, producto: "Audifonos", categoria: "Accesorios", vendedor: "Luis", cantidad: 6, precio: 1200, mes: "Marzo" },
  { id: 6, producto: "Tablet", categoria: "Tecnologia", vendedor: "Carlos", cantidad: 2, precio: 9500, mes: "Marzo" },
  { id: 7, producto: "Impresora", categoria: "Oficina", vendedor: "Ana", cantidad: 1, precio: 4800, mes: "Abril" },
  { id: 8, producto: "Silla", categoria: "Oficina", vendedor: "Luis", cantidad: 4, precio: 2600, mes: "Abril" },
  { id: 9, producto: "Webcam", categoria: "Tecnologia", vendedor: "Carlos", cantidad: 3, precio: 1750, mes: "Mayo" },
  { id: 10, producto: "Memoria USB", categoria: "Accesorios", vendedor: "Ana", cantidad: 10, precio: 220, mes: "Mayo" }
];

const totalVenta = (item) => item.cantidad * item.precio;

// API base
app.get("/api/ventas", (req, res) => res.json(ventas));

// COUNT: cantidad de ventas registradas
app.get("/api/estadisticas/count", (req, res) => {
  res.json({ totalVentas: ventas.length });
});

// SUM: ingresos totales
app.get("/api/estadisticas/sum", (req, res) => {
  const ingresos = ventas.reduce((total, item) => total + totalVenta(item), 0);
  res.json({ ingresosTotales: ingresos });
});

// AVG: promedio del valor de las ventas
app.get("/api/estadisticas/avg", (req, res) => {
  const promedio = ventas.reduce((total, item) => total + totalVenta(item), 0) / ventas.length;
  res.json({ promedioVenta: Number(promedio.toFixed(2)) });
});

// MAX y MIN: venta de mayor y menor valor
app.get("/api/estadisticas/max-min", (req, res) => {
  const ordenadas = [...ventas].sort((a, b) => totalVenta(a) - totalVenta(b));
  const menor = ordenadas[0];
  const mayor = ordenadas[ordenadas.length - 1];
  res.json({
    ventaMaxima: { ...mayor, total: totalVenta(mayor) },
    ventaMinima: { ...menor, total: totalVenta(menor) }
  });
});

// GROUP BY: ingresos agrupados por categoria
app.get("/api/estadisticas/categorias", (req, res) => {
  const grupos = {};
  ventas.forEach((item) => {
    grupos[item.categoria] = (grupos[item.categoria] || 0) + totalVenta(item);
  });
  res.json(Object.entries(grupos).map(([categoria, ingresos]) => ({ categoria, ingresos })));
});

// GROUP BY: cantidad de ventas agrupadas por mes
app.get("/api/estadisticas/meses", (req, res) => {
  const grupos = {};
  ventas.forEach((item) => {
    grupos[item.mes] = (grupos[item.mes] || 0) + 1;
  });
  res.json(Object.entries(grupos).map(([mes, cantidad]) => ({ mes, cantidad })));
});

// GROUP BY: ingresos agrupados por vendedor
app.get("/api/estadisticas/vendedores", (req, res) => {
  const grupos = {};
  ventas.forEach((item) => {
    grupos[item.vendedor] = (grupos[item.vendedor] || 0) + totalVenta(item);
  });
  res.json(Object.entries(grupos).map(([vendedor, ingresos]) => ({ vendedor, ingresos })));
});

app.get("/api", (req, res) => {
  res.json({
    mensaje: "API de estadisticas lista",
    endpoints: [
      "/api/ventas",
      "/api/estadisticas/count",
      "/api/estadisticas/sum",
      "/api/estadisticas/avg",
      "/api/estadisticas/max-min",
      "/api/estadisticas/categorias",
      "/api/estadisticas/meses",
      "/api/estadisticas/vendedores"
    ]
  });
});

app.listen(PORT, () => {
  console.log(`Servidor iniciado en http://localhost:${PORT}`);
});