# Charjs-Tarea — Dashboard con Chart.js

Proyecto académico que implementa un backend con Node.js y Express y una vista gráfica que consume sus APIs utilizando Chart.js.

## Requisitos
- Node.js instalado (versión 18 o superior recomendada).
- Conexión a Internet para cargar Chart.js y Google Fonts desde sus CDN.

## Cómo ejecutar
1. Descomprime el archivo ZIP.
2. Abre la carpeta `Charjs-Tarea` en Visual Studio Code.
3. Abre la terminal dentro de esa carpeta.
4. Ejecuta `npm install`.
5. Ejecuta `npm start`.
6. Abre en el navegador: `http://localhost:3000`.

No abras `index.html` directamente con doble clic. Debes iniciar el servidor para que el frontend pueda consultar las APIs.

## APIs implementadas
| Método | Endpoint | Agregación |
|---|---|---|
| GET | `/api/ventas` | Lista de registros |
| GET | `/api/estadisticas/count` | COUNT |
| GET | `/api/estadisticas/sum` | SUM |
| GET | `/api/estadisticas/avg` | AVG |
| GET | `/api/estadisticas/max-min` | MAX / MIN |
| GET | `/api/estadisticas/categorias` | GROUP BY categoría + SUM |
| GET | `/api/estadisticas/meses` | GROUP BY mes + COUNT |
| GET | `/api/estadisticas/vendedores` | GROUP BY vendedor + SUM |

## Estructura
- `server.js`: backend y endpoints REST.
- `public/index.html`: estructura de la vista.
- `public/styles.css`: diseño adaptable.
- `public/app.js`: consumo de APIs y gráficas Chart.js.

## Nota académica
Como no se proporcionó un backend previo ni un esquema de base de datos o una lista específica de APIs del docente, este proyecto utiliza un conjunto de datos de ejemplo incluido en el backend. Las agregaciones se calculan en el servidor y el frontend representa las respuestas reales de esos endpoints. Si el docente proporcionó APIs o agregaciones distintas, deben reemplazarse/adaptarse a esa especificación.
